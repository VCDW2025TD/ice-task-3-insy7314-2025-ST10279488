import React from "react";
import { Link, Outlet } from "react-router-dom";
import { isLoggedIn } from "../utils/auth";
import "./Layout.css";

export default function Layout() {
  const loggedIn = isLoggedIn();
  return (
    <>
      <nav className="main-nav">
        <ul>
          <li><Link to="/">Home</Link></li>
          {loggedIn ? (
            <>
              <li><Link to="/dashboard">Dashboard</Link></li>
              <li><Link to="/logout">Logout</Link></li>
            </>
          ) : (
            <>
              <li><Link to="/register">Register</Link></li>
              <li><Link to="/login">Login</Link></li>
            </>
          )}
        </ul>
      </nav>
      <main className="page-wrapper">
        <Outlet />
      </main>
      <footer className="site-footer">
        <p>© {new Date().getFullYear()} Your App</p>
      </footer>
    </>
  );
}
