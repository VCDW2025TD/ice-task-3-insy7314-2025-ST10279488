import React from "react";

export default function HomePage() {
  return (
    <div className="page-container">
      <h1>Home</h1>
      <p>Public landing page.</p>
    </div>
  );
}
