import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import { saveToken } from "../utils/auth";
import "./Auth.css";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    try {
      const res = await API.post("/auth/login", { email, password });
      const token = res?.data?.token;
      if (token) {
        saveToken(token);
        setSuccess("Login successful");
        navigate("/dashboard");
      } else {
        setError("Login succeeded but no token returned.");
      }
    } catch (err) {
      const status = err?.response?.status;
      if (status === 401 || status === 400) {
        setError("Invalid credentials");
      } else {
        setError(err?.response?.data?.message ?? "Login failed");
      }
    }
  };

  return (
    <div className="auth-container">
      <h2>Login</h2>
      {error && <div className="auth-error">{error}</div>}
      {success && <div className="auth-success">{success}</div>}
      <form onSubmit={handleSubmit} className="auth-form">
        <label>Email
          <input
            type="email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <label>Password
          <input
            type="password"
            value={password}
            required
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
