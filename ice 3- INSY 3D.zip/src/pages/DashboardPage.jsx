import React from "react";

export default function DashboardPage() {
  return (
    <div className="page-container">
      <h1>Dashboard</h1>
      <p>Welcome — this is a protected page. Only visible when logged in.</p>
    </div>
  );
}
