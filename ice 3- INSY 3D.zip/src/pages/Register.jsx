import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import { saveToken } from "../utils/auth";
import "./Auth.css";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    try {
      const res = await API.post("/auth/register", { email, password });
      const token = res?.data?.token;
      if (token) {
        saveToken(token);
        setSuccess("Registration complete");
        navigate("/dashboard");
      } else {
        setError("Registration succeeded but no token returned.");
      }
    } catch (err) {
      const msg = err?.response?.data?.message;
      setError(msg || (err.message ? err.message : "Registration failed"));
    }
  };

  return (
    <div className="auth-container">
      <h2>Register</h2>
      {error && <div className="auth-error">{error}</div>}
      {success && <div className="auth-success">{success}</div>}
      <form onSubmit={handleSubmit} className="auth-form">
        <label>Email
          <input
            type="email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
        </label>
        <label>Password
          <input
            type="password"
            value={password}
            required
            minLength={6}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter a strong password"
          />
        </label>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
