import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { removeToken } from "../utils/auth";

export default function LogoutPage() {
  const navigate = useNavigate();
  useEffect(() => {
    removeToken();
    navigate("/");
  }, [navigate]);
  return null;
}
